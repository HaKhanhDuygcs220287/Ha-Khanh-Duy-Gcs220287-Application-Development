﻿namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TextBox txtInput, txtShift, txtResult, txtSorted, txtAsciiIn, txtAsciiOut, txtLetterCount, txtHash;
        private System.Windows.Forms.Button btnEncode, btnDecode, btnClear;
        private System.Windows.Forms.Label lblInput, lblShift, lblCharCount, lblResult, lblSorted, lblAsciiIn, lblAsciiOut, lblLetterCount, lblHash;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.txtShift = new System.Windows.Forms.TextBox();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.txtSorted = new System.Windows.Forms.TextBox();
            this.txtAsciiIn = new System.Windows.Forms.TextBox();
            this.txtAsciiOut = new System.Windows.Forms.TextBox();
            this.txtLetterCount = new System.Windows.Forms.TextBox();
            this.txtHash = new System.Windows.Forms.TextBox();
            this.btnEncode = new System.Windows.Forms.Button();
            this.btnDecode = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lblCharCount = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblSorted = new System.Windows.Forms.Label();
            this.lblAsciiIn = new System.Windows.Forms.Label();
            this.lblAsciiOut = new System.Windows.Forms.Label();
            this.lblLetterCount = new System.Windows.Forms.Label();
            this.lblHash = new System.Windows.Forms.Label();

            // Form1
            this.ClientSize = new System.Drawing.Size(600, 360);
            this.Name = "Form1";
            this.Text = "Text Encoder / Decoder";

            // Label Input
            lblInput.Text = "Enter UPPERCASE text:";
            lblInput.Location = new System.Drawing.Point(20, 20);
            lblInput.AutoSize = true;

            txtInput.Location = new System.Drawing.Point(200, 20);
            txtInput.Size = new System.Drawing.Size(250, 25);
            txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
            txtInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInput_KeyPress);

            lblCharCount.Text = "Characters: 0/40";
            lblCharCount.Location = new System.Drawing.Point(460, 25);
            lblCharCount.AutoSize = true;

            lblShift.Text = "Shift value (-25 to 25):";
            lblShift.Location = new System.Drawing.Point(20, 60);
            lblShift.AutoSize = true;

            txtShift.Location = new System.Drawing.Point(200, 60);
            txtShift.Size = new System.Drawing.Size(100, 25);

            // Buttons
            btnEncode.Text = "Encode";
            btnEncode.Location = new System.Drawing.Point(80, 100);
            btnEncode.Click += new System.EventHandler(this.btnEncode_Click);

            btnDecode.Text = "Decode";
            btnDecode.Location = new System.Drawing.Point(180, 100);
            btnDecode.Click += new System.EventHandler(this.btnDecode_Click);

            btnClear.Text = "Clear";
            btnClear.Location = new System.Drawing.Point(280, 100);
            btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // Output
            lblResult.Text = "Result:";
            lblResult.Location = new System.Drawing.Point(20, 150);
            lblResult.AutoSize = true;

            txtResult.Location = new System.Drawing.Point(200, 150);
            txtResult.Size = new System.Drawing.Size(250, 25);
            txtResult.ReadOnly = true;

            lblSorted.Text = "Sorted:";
            lblSorted.Location = new System.Drawing.Point(20, 180);
            lblSorted.AutoSize = true;

            txtSorted.Location = new System.Drawing.Point(200, 180);
            txtSorted.Size = new System.Drawing.Size(250, 25);
            txtSorted.ReadOnly = true;

            lblAsciiIn.Text = "Input ASCII:";
            lblAsciiIn.Location = new System.Drawing.Point(20, 210);
            lblAsciiIn.AutoSize = true;

            txtAsciiIn.Location = new System.Drawing.Point(200, 210);
            txtAsciiIn.Size = new System.Drawing.Size(350, 25);
            txtAsciiIn.ReadOnly = true;

            lblAsciiOut.Text = "Output ASCII:";
            lblAsciiOut.Location = new System.Drawing.Point(20, 240);
            lblAsciiOut.AutoSize = true;

            txtAsciiOut.Location = new System.Drawing.Point(200, 240);
            txtAsciiOut.Size = new System.Drawing.Size(350, 25);
            txtAsciiOut.ReadOnly = true;

            lblLetterCount.Text = "Letter Count:";
            lblLetterCount.Location = new System.Drawing.Point(20, 270);
            lblLetterCount.AutoSize = true;

            txtLetterCount.Location = new System.Drawing.Point(200, 270);
            txtLetterCount.Size = new System.Drawing.Size(100, 25);
            txtLetterCount.ReadOnly = true;

            lblHash.Text = "SHA-256 Hash:";
            lblHash.Location = new System.Drawing.Point(20, 300);
            lblHash.AutoSize = true;

            txtHash.Location = new System.Drawing.Point(200, 300);
            txtHash.Size = new System.Drawing.Size(370, 25);
            txtHash.ReadOnly = true;

            // Add all controls
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                txtInput, txtShift, txtResult, txtSorted, txtAsciiIn, txtAsciiOut, txtLetterCount, txtHash,
                btnEncode, btnDecode, btnClear,
                lblInput, lblShift, lblCharCount, lblResult, lblSorted, lblAsciiIn, lblAsciiOut, lblLetterCount, lblHash
            });
        }
    }
}