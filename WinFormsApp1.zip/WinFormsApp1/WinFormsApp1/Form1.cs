﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;


namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.txtInput.KeyPress += new KeyPressEventHandler(txtInput_KeyPress);
            this.txtInput.TextChanged += new EventHandler(txtInput_TextChanged);
        }

        private void btnEncode_Click(object sender, EventArgs e)
        {
            ProcessInput(true);
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            ProcessInput(false);
        }

        private void ProcessInput(bool isEncoding)
        {
            string input = txtInput.Text;

            // Kiểm tra nếu input trống
            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("⚠️ Input cannot be empty.");
                return;
            }

            
            if (!input.Any(char.IsUpper))
            {
                MessageBox.Show("⚠️ Input must contain at least one uppercase letter (A-Z).");
                return;
            }

            // Kiểm tra giá trị Shift
            if (int.TryParse(txtShift.Text, out int shift))
            {
                if (shift < -25 || shift > 25)
                {
                    MessageBox.Show("⚠️ Shift value must be between -25 and 25.");
                    return;
                }

                
                string result = CaesarEncode(input, isEncoding ? shift : -shift);
                txtResult.Text = result;

                UpdateAdditionalInfo(input, result);
            }
            else
            {
                MessageBox.Show("⚠️ Please enter a valid number for Shift.");
            }
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            txtShift.Clear();
            txtResult.Clear();
            txtSorted.Clear();
            txtAsciiIn.Clear();
            txtAsciiOut.Clear();
            txtLetterCount.Clear();
            txtHash.Clear();
            lblCharCount.Text = "Characters: 0/40";
        }

        private string CaesarEncode(string input, int shift)
        {
            char[] buffer = input.ToCharArray();
            for (int i = 0; i < buffer.Length; i++)
            {
                char c = buffer[i];
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    buffer[i] = (char)(((c - offset + shift + 26) % 26) + offset);
                }
            }
            return new string(buffer);
        }

        private void UpdateAdditionalInfo(string input, string output)
        {
           
            txtSorted.Text = new string(input.Where(char.IsUpper).OrderBy(c => c).ToArray());

            
            txtAsciiIn.Text = string.Join(" ", input.Select(c => ((int)c).ToString()));
            txtAsciiOut.Text = string.Join(" ", output.Select(c => ((int)c).ToString()));

            
            txtLetterCount.Text = input.Count(char.IsLetter).ToString();

           
            txtHash.Text = GetSha256Hash(input);
        }

        private string GetSha256Hash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(input);
                byte[] hash = sha256.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }

        private void txtInput_TextChanged(object? sender, EventArgs e)
        {
            lblCharCount.Text = $"Characters: {txtInput.Text.Length}/40";
        }


        private void txtInput_KeyPress(object? sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnDecode.PerformClick();
                e.Handled = true;
            }
            else if (!char.IsControl(e.KeyChar) && char.IsLetter(e.KeyChar) && !char.IsUpper(e.KeyChar))
            {
                MessageBox.Show("⚠️ Please enter uppercase letters (A-Z).");
                e.Handled = true;
            }
            else if (txtInput.Text.Length >= 40 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

    }
}
    

